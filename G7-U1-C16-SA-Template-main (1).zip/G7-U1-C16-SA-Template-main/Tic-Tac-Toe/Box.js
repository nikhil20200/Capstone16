class Box {
  
    constructor() {
    this.x = ;
    this.y = ;
    this.w = ;
    this.h = ;
  }

    //make the color boxes appear on canvas
    appear()
    {
      stroke(0);
      strokeWeight(1);
      noFill();
      rect();
    }
}

